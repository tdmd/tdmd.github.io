This is a lockscreen widget for zelda fans.

Link holding the triforce with the battery status below him.

It ONLY works if you have LockHTML4 and Infostats2 installed.  Search reddit on how to install Infostats2.  I will not provide support.  This folder should be placed in the iwidgets folder (var/mobile/Library/iWidgets).  You can select it in LockHTML4.  Once selected, you can choose your "charging" font size.  Also, to center it, you have to go to advanced settings to reposition it.  Play with the numbers to get it where you'd like.

Enjoy!